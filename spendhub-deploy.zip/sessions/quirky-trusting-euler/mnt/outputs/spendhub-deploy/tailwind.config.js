/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Roboto', 'sans-serif'],
      },
      fontSize: {
        'ds-xxxs': ['10px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-xxs':  ['12px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-xs':   ['14px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-s':    ['16px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-m':    ['18px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-l':    ['24px', { lineHeight: '1.4', letterSpacing: '0.2px' }],
        'ds-xl':   ['32px', { lineHeight: '1.3', letterSpacing: '0.2px' }],
      },
      colors: {
        // Humand brand
        humand: {
          50:  '#f1f4fd',
          100: '#dee5fb',
          200: '#c5d4f8',
          300: '#9db8f3',
          400: '#6f93eb',
          500: '#496be3',
          600: '#3851d8',
          700: '#2f3fc6',
          800: '#2c35a1',
          900: '#29317f',
          950: '#1d204e',
        },
        // Neutral greys
        hn: {
          50:  '#f5f6f8',
          100: '#eeeef1',
          150: '#E9E9ED',
          200: '#dfe0e6',
          300: '#cbcdd6',
          400: '#b5b6c4',
          500: '#aaaaba',
          600: '#8d8c9f',
          700: '#79788a',
          800: '#636271',
          900: '#53525d',
          950: '#303036',
        },
        // Semantic
        'bp-100': '#eff2ff',   // blueprimary/100 – table headers
        'bp-800': '#213478',   // blueprimary/800 – text on bp-100
      },
      boxShadow: {
        '4dp':     '-1px 4px 8px 0px rgba(233,233,244,1)',
        '8dp':     '-1px 8px 16px 0px rgba(170,170,186,0.45)',
        'inv':     '0px -2px 24px 0px rgba(103,103,121,0.50)',
      },
      borderRadius: {
        's': '4px',
        'm': '8px',
        'l': '16px',
      },
    },
  },
  plugins: [],
}
