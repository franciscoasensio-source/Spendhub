import { Routes, Route, Navigate } from 'react-router-dom'
import Landing from './pages/Landing'
import GestionGastos from './pages/admin/GestionGastos'
import ConfiguracionSpendHub from './pages/admin/ConfiguracionSpendHub'
import MisGastos from './pages/colaborador/MisGastos'

export default function App() {
  return (
    <Routes>
      {/* Landing */}
      <Route path="/" element={<Landing />} />

      {/* Admin */}
      <Route path="/admin" element={<Navigate to="/admin/gastos" replace />} />
      <Route path="/admin/gastos"  element={<GestionGastos />} />
      <Route path="/admin/config"  element={<ConfiguracionSpendHub />} />
      <Route path="/admin/metrics" element={<Navigate to="/admin/gastos" replace />} />

      {/* Colaborador */}
      <Route path="/colaborador"        element={<Navigate to="/colaborador/gastos" replace />} />
      <Route path="/colaborador/gastos" element={<MisGastos />} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
