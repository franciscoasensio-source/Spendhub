import { useNavigate } from 'react-router-dom'
import { Settings, User, ArrowRight, BarChart2, Shield } from 'lucide-react'

export default function Landing() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-hn-50 flex flex-col items-center justify-center p-8">
      {/* Logo */}
      <div className="flex items-center gap-3 mb-2">
        <div
          className="w-12 h-12 rounded-l flex items-center justify-center text-white text-2xl font-bold"
          style={{ background: 'linear-gradient(135deg, #2c35a1 0%, #496be3 100%)' }}
        >
          H
        </div>
        <div>
          <span className="text-ds-l font-semibold text-hn-950">SpendHub</span>
          <span className="ml-2 text-ds-xs text-hn-600">by Humand</span>
        </div>
      </div>
      <p className="text-ds-xs text-hn-600 mb-12 text-center max-w-md">
        Gestión de gastos laborales: desde la solicitud del colaborador hasta el pago por finanzas.
      </p>

      {/* Role cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 w-full max-w-2xl">
        {/* Admin */}
        <RoleCard
          icon={<Shield size={28} className="text-humand-500" />}
          title="Vista Admin"
          description="Gestioná solicitudes, aprobá o rechazá gastos, y configurá categorías y políticas."
          features={['Gestión de gastos', 'Aprobar / Rechazar', 'Configuración']}
          cta="Entrar como Admin"
          bg="from-humand-50 to-humand-100"
          border="border-humand-200"
          onClick={() => navigate('/admin/gastos')}
        />

        {/* Colaborador */}
        <RoleCard
          icon={<User size={28} className="text-green-600" />}
          title="Vista Colaborador"
          description="Cargá tus gastos, seguí el estado de tus solicitudes y recibí notificaciones."
          features={['Nueva solicitud', 'Seguimiento de estado', 'Historial de gastos']}
          cta="Entrar como Colaborador"
          bg="from-green-50 to-emerald-50"
          border="border-green-200"
          onClick={() => navigate('/colaborador/gastos')}
        />
      </div>

      {/* Features */}
      <div className="mt-16 grid grid-cols-3 gap-8 max-w-2xl w-full text-center">
        <Feature icon={<BarChart2 size={20} className="text-humand-400" />} label="Flujo de aprobación automático" />
        <Feature icon={<Settings size={20} className="text-humand-400" />} label="Categorías y políticas configurables" />
        <Feature icon={<Shield size={20} className="text-humand-400" />} label="Control de presupuesto por equipo" />
      </div>

      <p className="mt-12 text-ds-xxs text-hn-400">Prototipo — Humand © 2026</p>
    </div>
  )
}

interface RoleCardProps {
  icon: React.ReactNode
  title: string
  description: string
  features: string[]
  cta: string
  bg: string
  border: string
  onClick: () => void
}

function RoleCard({ icon, title, description, features, cta, bg, border, onClick }: RoleCardProps) {
  return (
    <button
      onClick={onClick}
      className={`group text-left bg-gradient-to-br ${bg} border ${border} rounded-l p-6 shadow-4dp hover:shadow-8dp transition-all hover:-translate-y-0.5`}
    >
      <div className="mb-4">{icon}</div>
      <h2 className="text-ds-m font-semibold text-hn-950 mb-2">{title}</h2>
      <p className="text-ds-xs text-hn-700 mb-4">{description}</p>
      <ul className="space-y-1.5 mb-5">
        {features.map((f) => (
          <li key={f} className="flex items-center gap-2 text-ds-xxs text-hn-700">
            <span className="w-1.5 h-1.5 rounded-full bg-humand-400 flex-shrink-0" />
            {f}
          </li>
        ))}
      </ul>
      <div className="flex items-center gap-2 text-ds-xs font-semibold text-humand-600 group-hover:gap-3 transition-all">
        {cta} <ArrowRight size={14} />
      </div>
    </button>
  )
}

function Feature({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="w-10 h-10 rounded-m bg-white border border-hn-200 flex items-center justify-center shadow-4dp">
        {icon}
      </div>
      <p className="text-ds-xxs text-hn-600">{label}</p>
    </div>
  )
}
