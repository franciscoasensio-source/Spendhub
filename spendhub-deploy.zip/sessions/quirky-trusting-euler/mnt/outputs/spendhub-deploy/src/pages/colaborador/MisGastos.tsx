import { useState, useMemo } from 'react'
import { Search, Plus, X, ChevronRight, Check, AlertCircle, ArrowLeft } from 'lucide-react'
import { AppLayout, PageHeader } from '../../components/layout/AppLayout'
import { StatusBadge, CountBadge, CategoryChip } from '../../components/ui/Badge'
import { Avatar } from '../../components/ui/Avatar'
import {
  MOCK_REQUESTS, MOCK_POLICIES, STATUS_CONFIG,
  CURRENT_USER_COLABORADOR,
} from '../../data/mock'
import type { SpendRequest, RequestStatus, Currency } from '../../data/types'

const CURRENCIES: Currency[] = ['ARS', 'USD', 'EUR', 'BRL']

const MY_STATUSES: { key: RequestStatus | 'all'; label: string }[] = [
  { key: 'all',      label: 'Todas' },
  { key: 'pendiente', label: 'Pendiente' },
  { key: 'aprobado',  label: 'Aprobado' },
  { key: 'en_pago',   label: 'En pago' },
  { key: 'pagado',    label: 'Pagado' },
  { key: 'rechazado', label: 'Rechazado' },
]

function formatMonto(monto: number, moneda: string) {
  return `${moneda} ${monto.toLocaleString('es-AR')}`
}
function formatDate(d: string) {
  return new Date(d + 'T00:00:00').toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })
}

// ── Nueva solicitud — multi-step ─────────────────────────────────────────────

interface NuevaSolicitudProps {
  onClose: () => void
  onSubmit: (req: Omit<SpendRequest, 'id' | 'userId' | 'colaborador' | 'initials' | 'politica' | 'estado' | 'fechaCreacion'>) => void
}

function NuevaSolicitud({ onClose, onSubmit }: NuevaSolicitudProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [selectedCat, setSelectedCat] = useState('')
  const [monto, setMonto] = useState('')
  const [moneda, setMoneda] = useState<Currency>('ARS')
  const [fechaDesde, setFechaDesde] = useState('')
  const [fechaHasta, setFechaHasta] = useState('')
  const [descripcion, setDescripcion] = useState('')

  const userPolicy = MOCK_POLICIES.find((p) => p.id === CURRENT_USER_COLABORADOR.policyId)!
  const availableCategories = userPolicy.categories.map((c) => c.categoryName)

  const canGoStep2 = !!selectedCat
  const canGoStep3 = !!monto && Number(monto) > 0 && !!fechaDesde && !!descripcion.trim()

  const handleSubmit = () => {
    onSubmit({
      categoria: selectedCat,
      monto: Number(monto),
      moneda,
      descripcion,
      fechaDesde,
      fechaHasta: fechaHasta || fechaDesde,
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40">
      <div className="bg-white w-full sm:rounded-l sm:shadow-8dp sm:max-w-lg sm:mx-4 flex flex-col"
        style={{ maxHeight: '90vh' }}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-hn-100">
          {step > 1
            ? <button onClick={() => setStep((s) => (s - 1) as 1 | 2 | 3)} className="btn-ghost -ml-2">
                <ArrowLeft size={14} /> Atrás
              </button>
            : <div />
          }
          <h2 className="text-ds-s font-semibold text-hn-950">Nueva solicitud</h2>
          <button onClick={onClose} className="btn-ghost -mr-2 p-1.5"><X size={16} /></button>
        </div>

        {/* Progress */}
        <div className="flex px-6 py-3 gap-2 border-b border-hn-100">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-ds-xxxs font-bold flex-shrink-0 transition-colors ${
                step > s ? 'bg-green-500 text-white' : step === s ? 'bg-humand-500 text-white' : 'bg-hn-100 text-hn-500'
              }`}>
                {step > s ? <Check size={12} /> : s}
              </div>
              <span className={`text-ds-xxs font-medium ${step === s ? 'text-hn-950' : 'text-hn-400'}`}>
                {s === 1 ? 'Categoría' : s === 2 ? 'Detalles' : 'Confirmar'}
              </span>
              {s < 3 && <ChevronRight size={12} className="text-hn-300 ml-auto" />}
            </div>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {/* Step 1: Category */}
          {step === 1 && (
            <div>
              <p className="text-ds-xs text-hn-600 mb-4">
                Seleccioná la categoría para esta solicitud. Las opciones disponibles dependen de tu política asignada: <strong>{userPolicy.name}</strong>.
              </p>
              <div className="grid grid-cols-1 gap-3">
                {availableCategories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCat(cat)}
                    className={`flex items-center gap-4 p-4 rounded-l border-2 text-left transition-all ${
                      selectedCat === cat
                        ? 'border-humand-500 bg-humand-50'
                        : 'border-hn-200 hover:border-humand-300 hover:bg-hn-50'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-m flex items-center justify-center text-xl flex-shrink-0 ${
                      selectedCat === cat ? 'bg-humand-100' : 'bg-hn-100'
                    }`}>
                      {cat === 'Viajes' ? '✈️' : cat === 'Alimentación' ? '🍽️' : cat === 'Tecnología' ? '💻' : '📁'}
                    </div>
                    <div>
                      <p className={`text-ds-s font-semibold ${selectedCat === cat ? 'text-humand-700' : 'text-hn-950'}`}>{cat}</p>
                    </div>
                    {selectedCat === cat && (
                      <div className="ml-auto w-5 h-5 rounded-full bg-humand-500 flex items-center justify-center flex-shrink-0">
                        <Check size={12} className="text-white" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Details */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="label">Monto <span className="text-red-500">*</span></label>
                  <input
                    type="number"
                    min="0"
                    value={monto}
                    onChange={(e) => setMonto(e.target.value)}
                    placeholder="0"
                    className="input"
                  />
                </div>
                <div style={{ width: 100 }}>
                  <label className="label">Moneda</label>
                  <select value={moneda} onChange={(e) => setMoneda(e.target.value as Currency)}
                    className="w-full border border-hn-200 rounded-m px-3 py-2 text-ds-xs text-hn-950 outline-none focus:border-humand-400 bg-white">
                    {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="label">Fecha desde <span className="text-red-500">*</span></label>
                  <input type="date" value={fechaDesde} onChange={(e) => setFechaDesde(e.target.value)} className="input" />
                </div>
                <div className="flex-1">
                  <label className="label">Fecha hasta</label>
                  <input type="date" value={fechaHasta} min={fechaDesde} onChange={(e) => setFechaHasta(e.target.value)} className="input" />
                </div>
              </div>

              <div>
                <label className="label">Descripción <span className="text-red-500">*</span></label>
                <textarea
                  rows={4}
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                  placeholder="Describí el gasto con el detalle suficiente para que sea aprobado…"
                  className="input resize-none"
                />
                <p className="text-ds-xxs text-hn-500 mt-1">{descripcion.length}/500 caracteres</p>
              </div>

              <div>
                <label className="label">Comprobante (opcional)</label>
                <div className="border-2 border-dashed border-hn-200 rounded-m p-6 text-center hover:border-humand-300 hover:bg-humand-50 transition-colors cursor-pointer">
                  <p className="text-ds-xs text-hn-500">Arrastrá un archivo o</p>
                  <p className="text-ds-xxs text-humand-500 font-semibold mt-1">hacé clic para subir</p>
                  <p className="text-ds-xxxs text-hn-400 mt-2">PDF, JPG, PNG — máx. 10MB</p>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Confirm */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="bg-hn-50 rounded-l p-4 space-y-3">
                <div className="flex items-center gap-3 mb-4">
                  <Avatar initials={CURRENT_USER_COLABORADOR.initials} name={CURRENT_USER_COLABORADOR.name} size="md" />
                  <div>
                    <p className="text-ds-xs font-semibold text-hn-950">{CURRENT_USER_COLABORADOR.name}</p>
                    <p className="text-ds-xxs text-hn-600">{userPolicy.name}</p>
                  </div>
                </div>
                <ConfirmRow label="Categoría"   value={selectedCat} />
                <ConfirmRow label="Monto"       value={formatMonto(Number(monto), moneda)} />
                <ConfirmRow label="Descripción" value={descripcion} />
                <ConfirmRow label="Período"     value={fechaDesde ? `${formatDate(fechaDesde)}${fechaHasta ? ` → ${formatDate(fechaHasta)}` : ''}` : '—'} />
              </div>
              <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-m border border-yellow-100">
                <AlertCircle size={15} className="text-yellow-600 flex-shrink-0 mt-0.5" />
                <p className="text-ds-xxs text-yellow-700">
                  Una vez enviada, la solicitud pasará a revisión de tu aprobador. Recibirás una notificación con el resultado.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-hn-100">
          <button onClick={onClose} className="btn-secondary">Cancelar</button>
          {step < 3
            ? <button
                onClick={() => setStep((s) => (s + 1) as 2 | 3)}
                disabled={step === 1 ? !canGoStep2 : !canGoStep3}
                className={`btn-primary ${(step === 1 ? !canGoStep2 : !canGoStep3) ? 'opacity-40 cursor-not-allowed' : ''}`}
              >
                Siguiente <ChevronRight size={14} />
              </button>
            : <button onClick={handleSubmit} className="btn-primary">
                <Check size={14} /> Enviar solicitud
              </button>
          }
        </div>
      </div>
    </div>
  )
}

function ConfirmRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-ds-xxs font-semibold text-hn-500 flex-shrink-0">{label}</span>
      <span className="text-ds-xxs text-hn-950 text-right">{value}</span>
    </div>
  )
}

// ── My Gastos page ────────────────────────────────────────────────────────────

let _reqId = 900

export default function MisGastos() {
  const myUserId = CURRENT_USER_COLABORADOR.id
  const [allRequests, setAllRequests] = useState<SpendRequest[]>(MOCK_REQUESTS)
  const [activeStatus, setActiveStatus] = useState<RequestStatus | 'all'>('all')
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selected, setSelected] = useState<SpendRequest | null>(null)
  const [showSuccess, setShowSuccess] = useState(false)

  const myRequests = useMemo(
    () => allRequests.filter((r) => r.userId === myUserId),
    [allRequests]
  )

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: myRequests.length }
    myRequests.forEach((r) => { map[r.estado] = (map[r.estado] ?? 0) + 1 })
    return map
  }, [myRequests])

  const filtered = useMemo(() => myRequests.filter((r) => {
    const matchesStatus = activeStatus === 'all' || r.estado === activeStatus
    const matchesSearch = !search || [r.categoria, r.descripcion].some((v) => v.toLowerCase().includes(search.toLowerCase()))
    return matchesStatus && matchesSearch
  }), [myRequests, activeStatus, search])

  const handleNewRequest = (data: Omit<SpendRequest, 'id' | 'userId' | 'colaborador' | 'initials' | 'politica' | 'estado' | 'fechaCreacion'>) => {
    const userPolicy = MOCK_POLICIES.find((p) => p.id === CURRENT_USER_COLABORADOR.policyId)!
    const newReq: SpendRequest = {
      id: `req-${++_reqId}`,
      userId: myUserId,
      colaborador: CURRENT_USER_COLABORADOR.name,
      initials: CURRENT_USER_COLABORADOR.initials,
      politica: userPolicy.name,
      estado: 'pendiente',
      fechaCreacion: new Date().toISOString().split('T')[0],
      ...data,
    }
    setAllRequests((prev) => [newReq, ...prev])
    setShowModal(false)
    setShowSuccess(true)
    setTimeout(() => setShowSuccess(false), 3000)
  }

  return (
    <AppLayout role="colaborador">
      <PageHeader
        title="Mis Gastos"
        subtitle={`${CURRENT_USER_COLABORADOR.name} · ${MOCK_POLICIES.find((p) => p.id === CURRENT_USER_COLABORADOR.policyId)?.name}`}
        actions={
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={14} /> Nueva solicitud
          </button>
        }
      />

      {/* Success toast */}
      {showSuccess && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 bg-green-500 text-white text-ds-xs font-semibold rounded-m shadow-8dp animate-bounce">
          <Check size={16} /> Solicitud enviada correctamente
        </div>
      )}

      <div className="flex flex-1 overflow-hidden p-6 gap-5">
        {/* Left: filters */}
        <aside className="w-56 flex-shrink-0">
          <div className="card p-4">
            <p className="text-ds-xs font-semibold text-hn-950 mb-3">Mis solicitudes</p>
            <div className="space-y-0.5">
              {MY_STATUSES.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setActiveStatus(key)}
                  className={`filter-item w-full ${activeStatus === key ? 'filter-item-active' : ''}`}
                >
                  <span>{label}</span>
                  <CountBadge count={counts[key] ?? 0} active={activeStatus === key} />
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Right: table */}
        <div className="flex-1 min-w-0 flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-hn-400" />
              <input
                type="text"
                placeholder="Buscar por categoría o descripción…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input pl-8"
              />
            </div>
          </div>

          <div className="flex items-center gap-1 text-ds-xxs text-hn-600">
            <span>Solicitudes</span>
            <ChevronRight size={12} />
            <span className="text-hn-950 font-medium">
              {MY_STATUSES.find((s) => s.key === activeStatus)?.label ?? 'Todas'}
            </span>
          </div>

          <div className="card overflow-auto flex-1">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="th">Categoría</th>
                  <th className="th">Descripción</th>
                  <th className="th">Monto</th>
                  <th className="th">Estado</th>
                  <th className="th">Fecha</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="td text-center text-hn-400 py-16">
                      No tenés solicitudes{activeStatus !== 'all' ? ' en este estado' : ''}.
                      {activeStatus === 'all' && (
                        <span> <button onClick={() => setShowModal(true)} className="text-humand-500 font-semibold hover:underline">Creá una nueva</button>.</span>
                      )}
                    </td>
                  </tr>
                )}
                {filtered.map((req) => (
                  <tr
                    key={req.id}
                    onClick={() => setSelected(req)}
                    className={`cursor-pointer hover:bg-hn-50 transition-colors ${selected?.id === req.id ? 'bg-humand-50' : ''}`}
                  >
                    <td className="td">
                      <CategoryChip name={req.categoria} />
                    </td>
                    <td className="td text-hn-700 max-w-xs truncate">{req.descripcion}</td>
                    <td className="td font-semibold">{formatMonto(req.monto, req.moneda)}</td>
                    <td className="td"><StatusBadge status={req.estado} /></td>
                    <td className="td text-hn-600">{formatDate(req.fechaCreacion)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="flex items-center justify-between px-4 py-3 border-t border-hn-100">
              <span className="text-ds-xxs text-hn-600">{filtered.length} solicitud{filtered.length !== 1 ? 'es' : ''}</span>
            </div>
          </div>
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="w-72 flex-shrink-0 card flex flex-col" style={{ maxHeight: 'calc(100vh - 120px)' }}>
            <div className="flex items-center justify-between px-4 py-3 border-b border-hn-100">
              <span className="text-ds-xs font-semibold text-hn-950">Detalle</span>
              <button onClick={() => setSelected(null)} className="btn-ghost p-1"><X size={14} /></button>
            </div>
            <div className="flex-1 px-4 py-4 space-y-4 overflow-y-auto">
              <div className="flex items-center justify-between">
                <CategoryChip name={selected.categoria} />
                <StatusBadge status={selected.estado} />
              </div>
              <div>
                <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">Monto</p>
                <p className="text-ds-m font-semibold text-hn-950">{formatMonto(selected.monto, selected.moneda)}</p>
              </div>
              <div>
                <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">Descripción</p>
                <p className="text-ds-xs text-hn-800">{selected.descripcion}</p>
              </div>
              <div>
                <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">Fecha de carga</p>
                <p className="text-ds-xs text-hn-950">{formatDate(selected.fechaCreacion)}</p>
              </div>
              {selected.fechaDesde && (
                <div>
                  <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">Período</p>
                  <p className="text-ds-xs text-hn-950">{formatDate(selected.fechaDesde)}{selected.fechaHasta ? ` → ${formatDate(selected.fechaHasta)}` : ''}</p>
                </div>
              )}
              {selected.aprobadoPor && (
                <div>
                  <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">Gestionado por</p>
                  <p className="text-ds-xs text-hn-950">{selected.aprobadoPor}</p>
                </div>
              )}
              {selected.comentarioAprobador && (
                <div className="p-3 bg-red-50 rounded-m border border-red-100">
                  <p className="text-ds-xxs font-semibold text-red-700 mb-1">Motivo de rechazo</p>
                  <p className="text-ds-xxs text-red-600">{selected.comentarioAprobador}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <NuevaSolicitud
          onClose={() => setShowModal(false)}
          onSubmit={handleNewRequest}
        />
      )}
    </AppLayout>
  )
}
