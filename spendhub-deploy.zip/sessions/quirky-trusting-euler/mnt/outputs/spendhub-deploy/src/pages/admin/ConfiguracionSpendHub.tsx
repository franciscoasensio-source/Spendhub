import { useState } from 'react'
import { Plus, ChevronDown, ChevronUp, Pencil, Trash2, X } from 'lucide-react'
import { AppLayout, PageHeader } from '../../components/layout/AppLayout'
import { AvatarStack } from '../../components/ui/Avatar'
import { CategoryChip, CountBadge } from '../../components/ui/Badge'
import { MOCK_CATEGORIES, MOCK_POLICIES, MOCK_USERS, MOCK_SEGMENTS } from '../../data/mock'
import type {
  Category, CategoryRule, Policy,
  Condition, ConditionField, ConditionComparator, ConditionOperator,
  Approver, ApproverType, ApprovalRule, PaymentResponsible,
} from '../../data/types'

// ── ID counters ───────────────────────────────────────────────────────────────
let _catId = 200, _ruleId = 300, _polId = 400, _condId = 0, _apprId = 0

// ── Helpers ───────────────────────────────────────────────────────────────────
const CONDITION_FIELDS: { value: ConditionField; label: string }[] = [
  { value: 'department',           label: 'Departamento' },
  { value: 'amount',               label: 'Monto' },
  { value: 'position',             label: 'Puesto' },
  { value: 'segmentation',         label: 'Segmentación' },
  { value: 'profile',              label: 'Perfil' },
  { value: 'custom_profile_field', label: 'Campo personalizado' },
]
const CONDITION_OPS: { value: ConditionComparator; label: string }[] = [
  { value: '=',  label: '= igual' },
  { value: '>',  label: '> mayor' },
  { value: '<',  label: '< menor' },
  { value: '>=', label: '≥ mayor o igual' },
  { value: '<=', label: '≤ menor o igual' },
]
const APPROVER_TYPES: { value: ApproverType; label: string; needsValue: boolean }[] = [
  { value: 'specific_user',  label: 'Usuario específico',    needsValue: true  },
  { value: 'direct_manager', label: 'Jefe directo',          needsValue: false },
  { value: 'second_manager', label: 'Jefe de 2º nivel',      needsValue: false },
  { value: 'designated',     label: 'Aprobador designado',   needsValue: false },
  { value: 'segmentation',   label: 'Segmentación',          needsValue: true  },
  { value: 'dynamic_field',  label: 'Campo dinámico',        needsValue: true  },
]

const selectCls = 'w-full border border-hn-200 rounded-m px-3 py-2 text-ds-xs text-hn-950 outline-none focus:border-humand-400 bg-white'
const inputCls  = 'w-full border border-hn-200 rounded-m px-3 py-2 text-ds-xs text-hn-950 outline-none focus:border-humand-400'

// ── WorkflowBuilder ───────────────────────────────────────────────────────────

interface WFProps {
  conditions: Condition[]
  conditionOperator: ConditionOperator
  approvers: Approver[]
  approvalRule: ApprovalRule
  paymentResponsible: PaymentResponsible
  onConditionsChange: (c: Condition[]) => void
  onOperatorChange: (op: ConditionOperator) => void
  onApproversChange: (a: Approver[]) => void
  onApprovalRuleChange: (r: ApprovalRule) => void
  onPaymentChange: (p: PaymentResponsible) => void
}

function WorkflowBuilder(p: WFProps) {
  const addCondition = () => p.onConditionsChange([
    ...p.conditions,
    { id: `c${++_condId}`, field: 'department', operator: '=', value: '' },
  ])
  const addApprover = () => p.onApproversChange([
    ...p.approvers,
    { id: `a${++_apprId}`, type: 'direct_manager', value: '', label: 'Jefe directo' },
  ])

  return (
    <div className="space-y-6">
      {/* Conditions */}
      <section>
        <div className="flex items-center justify-between mb-2">
          <div>
            <h4 className="text-ds-xs font-semibold text-hn-950">Condicionales</h4>
            <p className="text-ds-xxs text-hn-600">Cuándo aplica esta regla.</p>
          </div>
          {p.conditions.length > 1 && (
            <div className="flex rounded-s overflow-hidden border border-hn-200">
              {(['AND', 'OR'] as ConditionOperator[]).map((op) => (
                <button key={op} type="button" onClick={() => p.onOperatorChange(op)}
                  className={`px-3 py-1 text-ds-xxs font-semibold transition-colors ${p.conditionOperator === op ? 'bg-humand-500 text-white' : 'bg-white text-hn-600 hover:bg-hn-50'}`}>
                  {op}
                </button>
              ))}
            </div>
          )}
        </div>
        {p.conditions.length === 0
          ? <p className="text-ds-xxs text-hn-400 italic px-3 py-2 bg-hn-50 rounded-m border border-dashed border-hn-200">Aplica a todos — sin condiciones.</p>
          : <div className="space-y-2">
              {p.conditions.map((cond, idx) => (
                <div key={cond.id}>
                  {idx > 0 && (
                    <div className="flex items-center gap-2 my-1">
                      <div className="flex-1 h-px bg-hn-100" />
                      <span className="text-ds-xxxs font-bold text-hn-400 px-2 py-0.5 bg-hn-100 rounded">{p.conditionOperator}</span>
                      <div className="flex-1 h-px bg-hn-100" />
                    </div>
                  )}
                  <div className="flex gap-2 p-2.5 bg-hn-50 rounded-m border border-hn-150">
                    <div className="flex-1">
                      <select value={cond.field} onChange={(e) => {
                        const updated = p.conditions.map((c) => c.id === cond.id ? { ...c, field: e.target.value as ConditionField } : c)
                        p.onConditionsChange(updated)
                      }} className={selectCls}>
                        {CONDITION_FIELDS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
                      </select>
                    </div>
                    <div style={{ minWidth: 130 }}>
                      <select value={cond.operator} onChange={(e) => {
                        const updated = p.conditions.map((c) => c.id === cond.id ? { ...c, operator: e.target.value as ConditionComparator } : c)
                        p.onConditionsChange(updated)
                      }} className={selectCls}>
                        {CONDITION_OPS.map((op) => <option key={op.value} value={op.value}>{op.label}</option>)}
                      </select>
                    </div>
                    <div className="flex-1">
                      <input type={cond.field === 'amount' ? 'number' : 'text'} value={cond.value}
                        onChange={(e) => {
                          const val = cond.field === 'amount' ? Number(e.target.value) : e.target.value
                          const updated = p.conditions.map((c) => c.id === cond.id ? { ...c, value: val } : c)
                          p.onConditionsChange(updated)
                        }}
                        placeholder={cond.field === 'amount' ? '0' : 'Valor…'}
                        className={inputCls} />
                    </div>
                    <button type="button" onClick={() => p.onConditionsChange(p.conditions.filter((c) => c.id !== cond.id))}
                      className="mt-0.5 w-8 h-8 flex items-center justify-center rounded-s text-hn-400 hover:bg-red-50 hover:text-red-500 transition-colors flex-shrink-0">
                      <X size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
        }
        <button type="button" onClick={addCondition}
          className="mt-2 flex items-center gap-2 text-ds-xxs font-semibold text-humand-500 hover:text-humand-700">
          <span className="w-5 h-5 rounded-full bg-humand-100 flex items-center justify-center text-humand-600 font-bold">+</span>
          Agregar condición
        </button>
      </section>

      {/* Approvers */}
      <section>
        <h4 className="text-ds-xs font-semibold text-hn-950 mb-1">Aprobadores</h4>
        {p.approvers.length === 0
          ? <p className="text-ds-xxs text-hn-400 italic px-3 py-2 bg-hn-50 rounded-m border border-dashed border-hn-200">Sin aprobadores — auto-aprobado.</p>
          : <div className="space-y-2">
              {p.approvers.map((appr) => {
                const cfg = APPROVER_TYPES.find((t) => t.value === appr.type)
                return (
                  <div key={appr.id} className="flex gap-2 p-2.5 bg-hn-50 rounded-m border border-hn-150">
                    <div style={{ minWidth: 180 }}>
                      <select value={appr.type} onChange={(e) => {
                        const type = e.target.value as ApproverType
                        const c = APPROVER_TYPES.find((t) => t.value === type)!
                        p.onApproversChange(p.approvers.map((a) => a.id === appr.id
                          ? { ...a, type, value: '', label: c.needsValue ? '' : c.label } : a))
                      }} className={selectCls}>
                        {APPROVER_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </div>
                    {cfg?.needsValue && (
                      appr.type === 'specific_user'
                        ? <select value={appr.value} onChange={(e) => {
                            const u = MOCK_USERS.find((u) => u.id === e.target.value)
                            if (u) p.onApproversChange(p.approvers.map((a) => a.id === appr.id ? { ...a, value: u.id, label: u.name } : a))
                          }} className={`${selectCls} flex-1`}>
                            <option value="">Seleccioná un usuario…</option>
                            {MOCK_USERS.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                          </select>
                        : appr.type === 'segmentation'
                        ? <select value={appr.value} onChange={(e) => {
                            const s = MOCK_SEGMENTS.find((s) => s.id === e.target.value)
                            if (s) p.onApproversChange(p.approvers.map((a) => a.id === appr.id ? { ...a, value: s.id, label: s.name } : a))
                          }} className={`${selectCls} flex-1`}>
                            <option value="">Seleccioná un segmento…</option>
                            {MOCK_SEGMENTS.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                          </select>
                        : <input type="text" value={appr.value}
                            onChange={(e) => p.onApproversChange(p.approvers.map((a) => a.id === appr.id ? { ...a, value: e.target.value, label: e.target.value } : a))}
                            placeholder="Nombre del campo…" className={`${inputCls} flex-1`} />
                    )}
                    {!cfg?.needsValue && <span className="flex-1 text-ds-xxs text-hn-400 italic self-center">Se resuelve automáticamente</span>}
                    <button type="button" onClick={() => p.onApproversChange(p.approvers.filter((a) => a.id !== appr.id))}
                      className="w-8 h-8 flex items-center justify-center rounded-s text-hn-400 hover:bg-red-50 hover:text-red-500 flex-shrink-0">
                      <X size={13} />
                    </button>
                  </div>
                )
              })}
            </div>
        }
        <button type="button" onClick={addApprover}
          className="mt-2 flex items-center gap-2 text-ds-xxs font-semibold text-humand-500 hover:text-humand-700">
          <span className="w-5 h-5 rounded-full bg-humand-100 flex items-center justify-center text-humand-600 font-bold">+</span>
          Agregar aprobador
        </button>
      </section>

      {/* Approval rule + Payment */}
      <section className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Regla de aprobación</label>
          <select value={p.approvalRule} onChange={(e) => p.onApprovalRuleChange(e.target.value as ApprovalRule)} className={selectCls}>
            <option value="all_must_approve">Todos deben aprobar</option>
            <option value="at_least_one">Al menos uno</option>
          </select>
        </div>
        <div>
          <label className="label">Responsable de pago</label>
          <div className="flex gap-2">
            <select value={p.paymentResponsible.type}
              onChange={(e) => p.onPaymentChange({ type: e.target.value as 'user' | 'role', value: '', label: '' })}
              className={`${selectCls} w-24 flex-shrink-0`}>
              <option value="user">Usuario</option>
              <option value="role">Rol</option>
            </select>
            {p.paymentResponsible.type === 'user'
              ? <select value={p.paymentResponsible.value} onChange={(e) => {
                  const u = MOCK_USERS.find((u) => u.id === e.target.value)
                  if (u) p.onPaymentChange({ type: 'user', value: u.id, label: u.name })
                }} className={`${selectCls} flex-1`}>
                  <option value="">Seleccioná…</option>
                  {MOCK_USERS.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              : <input type="text" value={p.paymentResponsible.value}
                  onChange={(e) => p.onPaymentChange({ type: 'role', value: e.target.value, label: e.target.value })}
                  placeholder="Ej: finanzas" className={`${inputCls} flex-1`} />
            }
          </div>
        </div>
      </section>
    </div>
  )
}

// ── Modal shell ───────────────────────────────────────────────────────────────

function Modal({ title, subtitle, onClose, onSave, canSave, children }: {
  title: string; subtitle?: string; onClose: () => void; onSave: () => void
  canSave: boolean; children: React.ReactNode
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-l shadow-8dp w-full flex flex-col" style={{ maxWidth: 680, maxHeight: '90vh' }}>
        <div className="flex items-start justify-between px-6 py-4 border-b border-hn-100 flex-shrink-0">
          <div>
            <h2 className="text-ds-s font-semibold text-hn-950">{title}</h2>
            {subtitle && <p className="text-ds-xxs text-hn-600 mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="btn-ghost p-1"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-hn-100 flex-shrink-0 bg-white">
          <button type="button" onClick={onClose} className="btn-secondary">Cancelar</button>
          <button type="button" onClick={onSave} disabled={!canSave}
            className={`btn-primary ${!canSave ? 'opacity-40 cursor-not-allowed' : ''}`}>
            Guardar
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Category manager ──────────────────────────────────────────────────────────

function CategoryManager() {
  const [categories, setCategories] = useState<Category[]>(MOCK_CATEGORIES)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [catModal, setCatModal] = useState<{ mode: 'create' | 'edit'; item?: Category } | null>(null)
  const [ruleModal, setRuleModal] = useState<{ catId: string; mode: 'create' | 'edit'; item?: CategoryRule } | null>(null)

  // Category state for modal
  const [catName, setCatName] = useState('')
  const [catDesc, setCatDesc] = useState('')

  // Rule state for modal
  const [ruleName, setRuleName] = useState('')
  const [conditions, setConditions] = useState<Condition[]>([])
  const [condOp, setCondOp] = useState<ConditionOperator>('AND')
  const [approvers, setApprovers] = useState<Approver[]>([])
  const [approvalRule, setApprovalRule] = useState<ApprovalRule>('at_least_one')
  const [payment, setPayment] = useState<PaymentResponsible>({ type: 'role', value: '', label: '' })

  const openCatCreate = () => { setCatName(''); setCatDesc(''); setCatModal({ mode: 'create' }) }
  const openCatEdit   = (c: Category) => { setCatName(c.name); setCatDesc(c.description); setCatModal({ mode: 'edit', item: c }) }
  const saveCat = () => {
    if (catModal?.mode === 'edit' && catModal.item) {
      setCategories((prev) => prev.map((c) => c.id === catModal.item!.id ? { ...c, name: catName, description: catDesc } : c))
    } else {
      setCategories((prev) => [...prev, { id: `cat-${++_catId}`, name: catName, description: catDesc, rules: [], createdAt: new Date().toISOString().split('T')[0] }])
    }
    setCatModal(null)
  }

  const openRuleCreate = (catId: string) => {
    setRuleName(''); setConditions([]); setCondOp('AND'); setApprovers([]); setApprovalRule('at_least_one'); setPayment({ type: 'role', value: '', label: '' })
    setRuleModal({ catId, mode: 'create' })
  }
  const openRuleEdit = (catId: string, rule: CategoryRule) => {
    setRuleName(rule.name); setConditions(rule.conditions); setCondOp(rule.conditionOperator); setApprovers(rule.approvers); setApprovalRule(rule.approvalRule); setPayment(rule.paymentResponsible)
    setRuleModal({ catId, mode: 'edit', item: rule })
  }
  const saveRule = () => {
    const data = { name: ruleName, conditions, conditionOperator: condOp, approvers, approvalRule, paymentResponsible: payment }
    setCategories((prev) => prev.map((cat) => {
      if (cat.id !== ruleModal!.catId) return cat
      if (ruleModal!.mode === 'edit' && ruleModal!.item) {
        return { ...cat, rules: cat.rules.map((r) => r.id === ruleModal!.item!.id ? { ...r, ...data } : r) }
      }
      return { ...cat, rules: [...cat.rules, { id: `rule-${++_ruleId}`, ...data }] }
    }))
    setRuleModal(null)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-ds-m font-semibold text-hn-950">Categorías</h2>
          <p className="text-ds-xs text-hn-600 mt-0.5">Tipos de gasto disponibles y sus flujos de aprobación.</p>
        </div>
        <button onClick={openCatCreate} className="btn-primary"><Plus size={14} /> Nueva categoría</button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="th">Nombre</th>
              <th className="th">Descripción</th>
              <th className="th text-center">Reglas</th>
              <th className="th text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((cat) => (
              <>
                <tr key={cat.id} className="hover:bg-hn-50 transition-colors">
                  <td className="td font-semibold">{cat.name}</td>
                  <td className="td text-hn-700 max-w-xs truncate">{cat.description || '—'}</td>
                  <td className="td text-center">
                    <CountBadge count={cat.rules.length} />
                  </td>
                  <td className="td text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button onClick={() => setExpandedId((p) => p === cat.id ? null : cat.id)}
                        className="btn-ghost text-humand-600 bg-humand-50">
                        {expandedId === cat.id ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                        {expandedId === cat.id ? 'Ocultar' : 'Ver reglas'}
                      </button>
                      <button onClick={() => openCatEdit(cat)} className="btn-ghost"><Pencil size={13} /></button>
                      <button onClick={() => {
                        if (window.confirm('¿Eliminar esta categoría?'))
                          setCategories((p) => p.filter((c) => c.id !== cat.id))
                      }} className="btn-ghost text-red-500 hover:bg-red-50"><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
                {expandedId === cat.id && (
                  <tr key={`${cat.id}-rules`}>
                    <td colSpan={4} className="bg-hn-50 border-b border-hn-100 px-6 py-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-ds-xs font-semibold text-hn-950">Reglas de <span className="text-humand-600">{cat.name}</span></span>
                        <button onClick={() => openRuleCreate(cat.id)} className="btn-secondary text-ds-xxs py-1.5"><Plus size={13} /> Nueva regla</button>
                      </div>
                      {cat.rules.length === 0
                        ? <p className="text-ds-xs text-hn-400 italic py-4 text-center border-2 border-dashed border-hn-200 rounded-m">Sin reglas.</p>
                        : <div className="space-y-3">
                            {cat.rules.map((rule) => (
                              <div key={rule.id} className="bg-white rounded-m border border-hn-200 p-4">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-ds-xs font-semibold text-hn-950">{rule.name}</span>
                                  <div className="flex gap-1.5">
                                    <button onClick={() => openRuleEdit(cat.id, rule)} className="btn-ghost py-1"><Pencil size={12} /></button>
                                    <button onClick={() => {
                                      if (window.confirm('¿Eliminar esta regla?'))
                                        setCategories((prev) => prev.map((c) => c.id === cat.id ? { ...c, rules: c.rules.filter((r) => r.id !== rule.id) } : c))
                                    }} className="btn-ghost py-1 text-red-500 hover:bg-red-50"><Trash2 size={12} /></button>
                                  </div>
                                </div>
                                <div className="flex gap-6 text-ds-xxs text-hn-600">
                                  <span><span className="font-semibold text-hn-400">Condiciones:</span> {rule.conditions.length === 0 ? 'Todas' : rule.conditions.map((c) => `${c.field} ${c.operator} ${c.value}`).join(` ${rule.conditionOperator} `)}</span>
                                  <span><span className="font-semibold text-hn-400">Aprobadores:</span> {rule.approvers.map((a) => a.label).join(', ') || '—'}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                      }
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>

      {/* Category modal */}
      {catModal && (
        <Modal title={catModal.mode === 'create' ? 'Nueva categoría' : 'Editar categoría'}
          onClose={() => setCatModal(null)} onSave={saveCat} canSave={!!catName.trim()}>
          <div className="space-y-4">
            <div>
              <label className="label">Nombre <span className="text-red-500">*</span></label>
              <input value={catName} onChange={(e) => setCatName(e.target.value)} placeholder="Ej: Viajes, Alimentación…" className="input" />
              <p className="text-ds-xxs text-hn-500 mt-1">Este nombre es visible para el colaborador.</p>
            </div>
            <div>
              <label className="label">Descripción</label>
              <textarea value={catDesc} onChange={(e) => setCatDesc(e.target.value)} rows={3} className="input resize-none" placeholder="Describí brevemente esta categoría…" />
            </div>
          </div>
        </Modal>
      )}

      {/* Rule modal */}
      {ruleModal && (
        <Modal title={ruleModal.mode === 'create' ? 'Nueva regla' : 'Editar regla'}
          subtitle="Las reglas son internas y no las ve el colaborador."
          onClose={() => setRuleModal(null)} onSave={saveRule} canSave={!!ruleName.trim()}>
          <div className="space-y-6">
            <div>
              <label className="label">Nombre de la regla <span className="text-red-500">*</span></label>
              <input value={ruleName} onChange={(e) => setRuleName(e.target.value)} placeholder="Ej: Viajes nacionales…" className="input" />
            </div>
            <div className="h-px bg-hn-100" />
            <WorkflowBuilder
              conditions={conditions} conditionOperator={condOp} approvers={approvers}
              approvalRule={approvalRule} paymentResponsible={payment}
              onConditionsChange={setConditions} onOperatorChange={setCondOp}
              onApproversChange={setApprovers} onApprovalRuleChange={setApprovalRule}
              onPaymentChange={setPayment} />
          </div>
        </Modal>
      )}
    </div>
  )
}

// ── Policy manager ────────────────────────────────────────────────────────────

function PolicyManager() {
  const [policies, setPolicies] = useState<Policy[]>(MOCK_POLICIES)
  const [modal, setModal] = useState<{ mode: 'create' | 'edit'; item?: Policy } | null>(null)

  const [polName, setPolName] = useState('')
  const [polCategories, setPolCategories] = useState<Policy['categories']>([])
  const [polMembers, setPolMembers] = useState<Policy['members']>([])
  const [polVisib, setPolVisib] = useState<Policy['members']>([])
  const [memberSearch, setMemberSearch] = useState('')
  const [visibSearch, setVisibSearch] = useState('')

  const allCategories = MOCK_CATEGORIES

  const openCreate = () => {
    setPolName(''); setPolCategories([]); setPolMembers([]); setPolVisib([]); setMemberSearch(''); setVisibSearch('')
    setModal({ mode: 'create' })
  }
  const openEdit = (p: Policy) => {
    setPolName(p.name); setPolCategories(p.categories); setPolMembers(p.members); setPolVisib(p.visibility); setMemberSearch(''); setVisibSearch('')
    setModal({ mode: 'edit', item: p })
  }
  const save = () => {
    const data = { name: polName, categories: polCategories, members: polMembers, visibility: polVisib }
    if (modal?.mode === 'edit' && modal.item) {
      setPolicies((prev) => prev.map((p) => p.id === modal.item!.id ? { ...p, ...data } : p))
    } else {
      setPolicies((prev) => [...prev, { id: `pol-${++_polId}`, createdAt: new Date().toISOString().split('T')[0], ...data }])
    }
    setModal(null)
  }

  const candidateMembers = MOCK_USERS.filter((u) => !polMembers.find((m) => m.userId === u.id) && u.name.toLowerCase().includes(memberSearch.toLowerCase()))
  const candidateVisib   = MOCK_USERS.filter((u) => !polVisib.find((v) => v.userId === u.id) && u.name.toLowerCase().includes(visibSearch.toLowerCase()))

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-ds-m font-semibold text-hn-950">Políticas</h2>
          <p className="text-ds-xs text-hn-600 mt-0.5">Asigná categorías y colaboradores a cada política.</p>
        </div>
        <button onClick={openCreate} className="btn-primary"><Plus size={14} /> Nueva política</button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="th">Nombre</th>
              <th className="th">Categorías</th>
              <th className="th">Colaboradores</th>
              <th className="th">Visibilidad</th>
              <th className="th text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {policies.map((pol) => (
              <tr key={pol.id} className="hover:bg-hn-50 transition-colors">
                <td className="td font-semibold">{pol.name}</td>
                <td className="td">
                  <div className="flex flex-wrap gap-1">
                    {pol.categories.slice(0, 3).map((c) => (
                      <CategoryChip key={c.categoryId} name={c.categoryName} />
                    ))}
                    {pol.categories.length > 3 && (
                      <span className="text-ds-xxs text-hn-600 self-center">+{pol.categories.length - 3}</span>
                    )}
                  </div>
                </td>
                <td className="td">
                  <div className="flex items-center gap-2">
                    <AvatarStack items={pol.members} max={4} />
                    <span className="text-ds-xxs text-hn-600">{pol.members.length} colaborador{pol.members.length !== 1 ? 'es' : ''}</span>
                  </div>
                </td>
                <td className="td">
                  {pol.visibility.length === 0
                    ? <span className="text-ds-xxs text-hn-400 italic">—</span>
                    : <AvatarStack items={pol.visibility} max={3} />
                  }
                </td>
                <td className="td text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <button onClick={() => openEdit(pol)} className="btn-ghost"><Pencil size={13} /></button>
                    <button onClick={() => {
                      if (window.confirm('¿Eliminar esta política?'))
                        setPolicies((p) => p.filter((pol2) => pol2.id !== pol.id))
                    }} className="btn-ghost text-red-500 hover:bg-red-50"><Trash2 size={13} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <Modal title={modal.mode === 'create' ? 'Nueva política' : 'Editar política'}
          onClose={() => setModal(null)} onSave={save} canSave={!!polName.trim() && polCategories.length > 0}>
          <div className="space-y-6">
            <div>
              <label className="label">Nombre <span className="text-red-500">*</span></label>
              <input value={polName} onChange={(e) => setPolName(e.target.value)} placeholder="Ej: Política Comercial…" className="input" />
            </div>

            <div>
              <label className="label">Categorías <span className="text-red-500">*</span></label>
              <div className="flex flex-wrap gap-2 mb-2">
                {polCategories.map((c) => (
                  <CategoryChip key={c.categoryId} name={c.categoryName}
                    onRemove={() => setPolCategories((prev) => prev.filter((x) => x.categoryId !== c.categoryId))} />
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                {allCategories.filter((c) => !polCategories.find((s) => s.categoryId === c.id)).map((c) => (
                  <button key={c.id} type="button"
                    onClick={() => setPolCategories((prev) => [...prev, { categoryId: c.id, categoryName: c.name }])}
                    className="text-ds-xxs font-medium px-3 py-1 rounded-full border border-hn-200 text-hn-700 hover:border-humand-300 hover:text-humand-600 transition-colors">
                    + {c.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="label">Colaboradores</label>
              <div className="relative mb-2">
                <input value={memberSearch} onChange={(e) => setMemberSearch(e.target.value)} placeholder="Buscar colaboradores…" className="input" />
                {memberSearch && candidateMembers.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-hn-200 rounded-m shadow-8dp z-10 max-h-40 overflow-y-auto">
                    {candidateMembers.map((u) => (
                      <button key={u.id} type="button" onClick={() => { setPolMembers((p) => [...p, { userId: u.id, name: u.name, initials: u.initials }]); setMemberSearch('') }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-hn-50 text-left">
                        <span className="text-ds-xs font-medium">{u.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {polMembers.map((m) => (
                <div key={m.userId} className="flex items-center justify-between py-2 px-3 hover:bg-hn-50 rounded-s">
                  <span className="text-ds-xs text-hn-950">{m.name}</span>
                  <button onClick={() => setPolMembers((p) => p.filter((x) => x.userId !== m.userId))} className="text-hn-400 hover:text-red-500"><X size={13} /></button>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

type ConfigTab = 'categorias' | 'politicas'

export default function ConfiguracionSpendHub() {
  const [tab, setTab] = useState<ConfigTab>('categorias')

  return (
    <AppLayout role="admin">
      <div className="bg-white border-b border-hn-200 px-8 py-5">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-m bg-humand-500 flex items-center justify-center text-white text-lg">💰</div>
          <div>
            <h1 className="text-ds-l font-semibold text-hn-950">SpendHub — Configuración</h1>
            <p className="text-ds-xs text-hn-600">Categorías y políticas de gastos</p>
          </div>
        </div>
        <nav className="flex gap-0 -mb-px border-b border-hn-200">
          {([['categorias', 'Categorías'], ['politicas', 'Políticas']] as const).map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)}
              className={`px-5 py-3 text-ds-xs font-semibold border-b-2 transition-colors ${
                tab === key ? 'border-humand-500 text-humand-600' : 'border-transparent text-hn-600 hover:text-hn-950'
              }`}>
              {label}
            </button>
          ))}
        </nav>
      </div>
      <div className="p-8">
        {tab === 'categorias' && <CategoryManager />}
        {tab === 'politicas'  && <PolicyManager />}
      </div>
    </AppLayout>
  )
}
