import { useState, useMemo } from 'react'
import { Search, Filter, X, Check, XCircle, CreditCard, ChevronRight } from 'lucide-react'
import { AppLayout, PageHeader } from '../../components/layout/AppLayout'
import { StatusBadge, CountBadge } from '../../components/ui/Badge'
import { Avatar } from '../../components/ui/Avatar'
import { MOCK_REQUESTS, STATUS_CONFIG } from '../../data/mock'
import type { SpendRequest, RequestStatus } from '../../data/types'

const ALL_STATUSES: { key: RequestStatus | 'all'; label: string }[] = [
  { key: 'all',                 label: 'Todas' },
  { key: 'pendiente',           label: 'Pendiente' },
  { key: 'aprobado',            label: 'Aprobado' },
  { key: 'en_pago',             label: 'En pago' },
  { key: 'pagado',              label: 'Pagado' },
  { key: 'rechazado',           label: 'Rechazado' },
  { key: 'rendicion_pendiente', label: 'Rendición pendiente' },
]

function formatMonto(monto: number, moneda: string) {
  return `${moneda} ${monto.toLocaleString('es-AR')}`
}

function formatDate(d: string) {
  return new Date(d + 'T00:00:00').toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })
}

export default function GestionGastos() {
  const [requests, setRequests] = useState<SpendRequest[]>(MOCK_REQUESTS)
  const [activeStatus, setActiveStatus] = useState<RequestStatus | 'all'>('all')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<SpendRequest | null>(null)
  const [rejectComment, setRejectComment] = useState('')
  const [showRejectForm, setShowRejectForm] = useState(false)

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: requests.length }
    requests.forEach((r) => { map[r.estado] = (map[r.estado] ?? 0) + 1 })
    return map
  }, [requests])

  const filtered = useMemo(() => {
    return requests.filter((r) => {
      const matchesStatus = activeStatus === 'all' || r.estado === activeStatus
      const matchesSearch = !search || [r.colaborador, r.categoria, r.descripcion, r.politica]
        .some((v) => v.toLowerCase().includes(search.toLowerCase()))
      return matchesStatus && matchesSearch
    })
  }, [requests, activeStatus, search])

  const updateStatus = (id: string, estado: RequestStatus, extra?: Partial<SpendRequest>) => {
    setRequests((prev) => prev.map((r) => r.id === id ? { ...r, estado, ...extra } : r))
    setSelected((prev) => prev?.id === id ? { ...prev, estado, ...extra } : prev)
    setShowRejectForm(false)
    setRejectComment('')
  }

  return (
    <AppLayout role="admin">
      <PageHeader
        title="Gestión de Gastos"
        subtitle="Revisá y gestioná todas las solicitudes de gasto"
      />

      <div className="flex flex-1 overflow-hidden p-6 gap-5">
        {/* ── Left: filters ── */}
        <aside className="w-60 flex-shrink-0">
          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-ds-xs font-semibold text-hn-950">Estados</span>
              <Filter size={14} className="text-hn-400" />
            </div>
            <div className="space-y-0.5">
              {ALL_STATUSES.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setActiveStatus(key)}
                  className={`filter-item w-full ${activeStatus === key ? 'filter-item-active' : ''}`}
                >
                  <span>{label}</span>
                  <CountBadge count={counts[key] ?? 0} active={activeStatus === key} />
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* ── Right: table ── */}
        <div className="flex-1 min-w-0 flex flex-col gap-4">
          {/* Header row */}
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-hn-400" />
              <input
                type="text"
                placeholder="Buscar colaborador, categoría o descripción…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input pl-8"
              />
            </div>
            <button className="btn-secondary">
              <Filter size={14} /> Filtrar
            </button>
          </div>

          {/* Breadcrumb */}
          <div className="flex items-center gap-1 text-ds-xxs text-hn-600">
            <span>Solicitudes</span>
            <ChevronRight size={12} />
            <span className="text-hn-950 font-medium">
              {ALL_STATUSES.find((s) => s.key === activeStatus)?.label ?? 'Todas'}
            </span>
          </div>

          {/* Table */}
          <div className="card overflow-auto flex-1">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="th">Colaborador</th>
                  <th className="th">Categoría</th>
                  <th className="th">Monto</th>
                  <th className="th">Estado</th>
                  <th className="th">Fecha</th>
                  <th className="th">Política</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={6} className="td text-center text-hn-400 py-16">
                      No hay solicitudes para el filtro seleccionado.
                    </td>
                  </tr>
                )}
                {filtered.map((req) => (
                  <tr
                    key={req.id}
                    onClick={() => { setSelected(req); setShowRejectForm(false) }}
                    className={`cursor-pointer hover:bg-hn-50 transition-colors ${
                      selected?.id === req.id ? 'bg-humand-50' : ''
                    }`}
                  >
                    <td className="td">
                      <div className="flex items-center gap-2.5">
                        <Avatar initials={req.initials} name={req.colaborador} size="xs" />
                        <span className="font-medium">{req.colaborador}</span>
                      </div>
                    </td>
                    <td className="td text-hn-700">{req.categoria}</td>
                    <td className="td font-semibold">{formatMonto(req.monto, req.moneda)}</td>
                    <td className="td"><StatusBadge status={req.estado} /></td>
                    <td className="td text-hn-600">{formatDate(req.fechaCreacion)}</td>
                    <td className="td text-hn-600">{req.politica}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Pagination placeholder */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-hn-100">
              <span className="text-ds-xxs text-hn-600">{filtered.length} solicitud{filtered.length !== 1 ? 'es' : ''}</span>
              <div className="flex items-center gap-2">
                <button className="btn-ghost opacity-40" disabled>‹</button>
                <span className="w-8 h-8 flex items-center justify-center rounded-s bg-humand-500 text-white text-ds-xxs font-semibold">1</span>
                <button className="btn-ghost opacity-40" disabled>›</button>
                <select className="input w-auto text-ds-xxs py-1.5">
                  <option>10/página</option>
                  <option>25/página</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* ── Detail panel ── */}
        {selected && (
          <div className="w-80 flex-shrink-0 card flex flex-col" style={{ maxHeight: 'calc(100vh - 120px)', overflowY: 'auto' }}>
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-hn-100">
              <span className="text-ds-xs font-semibold text-hn-950">Detalle</span>
              <button onClick={() => setSelected(null)} className="btn-ghost p-1.5">
                <X size={14} />
              </button>
            </div>

            <div className="flex-1 px-4 py-4 space-y-5 overflow-y-auto">
              {/* Collaborator */}
              <div className="flex items-center gap-3">
                <Avatar initials={selected.initials} name={selected.colaborador} size="md" />
                <div>
                  <p className="text-ds-xs font-semibold text-hn-950">{selected.colaborador}</p>
                  <p className="text-ds-xxs text-hn-600">{selected.politica}</p>
                </div>
              </div>

              <StatusBadge status={selected.estado} />

              {/* Fields */}
              <DetailField label="Categoría"    value={selected.categoria} />
              <DetailField label="Monto"        value={formatMonto(selected.monto, selected.moneda)} />
              <DetailField label="Descripción"  value={selected.descripcion} />
              <DetailField label="Fecha carga"  value={formatDate(selected.fechaCreacion)} />
              {selected.fechaDesde && (
                <DetailField
                  label="Período"
                  value={`${formatDate(selected.fechaDesde)} → ${formatDate(selected.fechaHasta!)}`}
                />
              )}
              {selected.aprobadoPor && (
                <DetailField label="Gestionado por" value={selected.aprobadoPor} />
              )}
              {selected.comentarioAprobador && (
                <div className="p-3 bg-red-50 rounded-m border border-red-100">
                  <p className="text-ds-xxs font-semibold text-red-700 mb-1">Motivo de rechazo</p>
                  <p className="text-ds-xxs text-red-600">{selected.comentarioAprobador}</p>
                </div>
              )}
            </div>

            {/* Actions */}
            {selected.estado === 'pendiente' && (
              <div className="px-4 py-4 border-t border-hn-100 space-y-3">
                {!showRejectForm ? (
                  <div className="flex gap-2">
                    <button
                      onClick={() => updateStatus(selected.id, 'aprobado', { aprobadoPor: 'Marcela Ríos' })}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-green-500 text-white text-ds-xxs font-semibold rounded-m hover:bg-green-600 transition-colors"
                    >
                      <Check size={13} /> Aprobar
                    </button>
                    <button
                      onClick={() => setShowRejectForm(true)}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-red-50 text-red-600 text-ds-xxs font-semibold rounded-m border border-red-200 hover:bg-red-100 transition-colors"
                    >
                      <XCircle size={13} /> Rechazar
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <textarea
                      rows={3}
                      placeholder="Motivo del rechazo…"
                      value={rejectComment}
                      onChange={(e) => setRejectComment(e.target.value)}
                      className="input resize-none text-ds-xxs"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowRejectForm(false)}
                        className="flex-1 btn-secondary text-ds-xxs justify-center py-1.5"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={() => updateStatus(selected.id, 'rechazado', {
                          comentarioAprobador: rejectComment || 'Sin comentario.',
                          aprobadoPor: 'Marcela Ríos',
                        })}
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-red-500 text-white text-ds-xxs font-semibold rounded-m hover:bg-red-600 transition-colors"
                      >
                        Confirmar rechazo
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {selected.estado === 'aprobado' && (
              <div className="px-4 py-4 border-t border-hn-100">
                <button
                  onClick={() => updateStatus(selected.id, 'en_pago')}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-humand-500 text-white text-ds-xxs font-semibold rounded-m hover:bg-humand-600 transition-colors"
                >
                  <CreditCard size={13} /> Procesar pago
                </button>
              </div>
            )}

            {selected.estado === 'en_pago' && (
              <div className="px-4 py-4 border-t border-hn-100">
                <button
                  onClick={() => updateStatus(selected.id, 'pagado')}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-green-500 text-white text-ds-xxs font-semibold rounded-m hover:bg-green-600 transition-colors"
                >
                  <Check size={13} /> Marcar como pagado
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  )
}

function DetailField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-ds-xxxs font-semibold text-hn-500 uppercase tracking-wide mb-1">{label}</p>
      <p className="text-ds-xs text-hn-950">{value}</p>
    </div>
  )
}
