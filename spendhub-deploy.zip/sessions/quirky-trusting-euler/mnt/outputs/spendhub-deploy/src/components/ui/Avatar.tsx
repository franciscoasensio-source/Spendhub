interface AvatarProps {
  initials: string
  name?: string
  size?: 'xs' | 'sm' | 'md'
}

const sizeMap = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-ds-xxs',
  md: 'w-10 h-10 text-ds-xs',
}

export function Avatar({ initials, name, size = 'sm' }: AvatarProps) {
  return (
    <div
      title={name}
      className={`${sizeMap[size]} rounded-full flex items-center justify-center font-semibold text-white flex-shrink-0`}
      style={{ background: 'linear-gradient(135deg, #2c35a1 0%, #496be3 100%)' }}
    >
      {initials}
    </div>
  )
}

interface AvatarStackProps {
  items: { initials: string; name: string }[]
  max?: number
}

export function AvatarStack({ items, max = 4 }: AvatarStackProps) {
  const visible  = items.slice(0, max)
  const overflow = items.length - max
  return (
    <div className="flex items-center">
      <div className="flex">
        {visible.map((item, i) => (
          <div
            key={i}
            title={item.name}
            className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-semibold text-white flex-shrink-0"
            style={{
              background: 'linear-gradient(135deg, #2c35a1 0%, #496be3 100%)',
              marginLeft: i > 0 ? '-6px' : '0',
            }}
          >
            {item.initials}
          </div>
        ))}
      </div>
      {overflow > 0 && (
        <span className="ml-1.5 text-ds-xxs font-medium text-hn-600">+{overflow}</span>
      )}
    </div>
  )
}
