import { STATUS_CONFIG } from '../../data/mock'
import type { RequestStatus } from '../../data/types'

interface StatusBadgeProps {
  status: RequestStatus | string
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const cfg = STATUS_CONFIG[status] ?? { label: status, bg: '#eeeef1', color: '#636271', dotColor: '#aaaaba' }
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-ds-xxs font-semibold whitespace-nowrap"
      style={{ background: cfg.bg, color: cfg.color }}
    >
      <span
        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
        style={{ background: cfg.dotColor }}
      />
      {cfg.label}
    </span>
  )
}

interface CountBadgeProps {
  count: number
  active?: boolean
}

export function CountBadge({ count, active = false }: CountBadgeProps) {
  return (
    <span
      className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-ds-xxxs font-semibold ${
        active
          ? 'bg-humand-100 text-humand-700'
          : 'bg-hn-100 text-hn-700'
      }`}
    >
      {count}
    </span>
  )
}

interface CategoryChipProps {
  name: string
  onRemove?: () => void
}

export function CategoryChip({ name, onRemove }: CategoryChipProps) {
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-ds-xxs font-medium bg-humand-50 text-humand-700">
      {name}
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="hover:text-humand-900 transition-colors leading-none"
        >
          ×
        </button>
      )}
    </span>
  )
}
