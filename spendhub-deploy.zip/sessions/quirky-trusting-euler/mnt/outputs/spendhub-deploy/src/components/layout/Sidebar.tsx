import { NavLink, useLocation } from 'react-router-dom'
import {
  Clock, Users, Newspaper, LayoutGrid, FileText, ClipboardList,
  Heart, GraduationCap, Settings, ChevronDown, ChevronRight,
  Wallet, BarChart2, Sliders, UserCheck,
} from 'lucide-react'
import { useState } from 'react'
import type { Role } from '../../data/types'
import { CURRENT_USER_ADMIN, CURRENT_USER_COLABORADOR } from '../../data/mock'
import { Avatar } from '../ui/Avatar'

interface SidebarProps {
  role: Role
}

export function Sidebar({ role }: SidebarProps) {
  const [spendHubOpen, setSpendHubOpen] = useState(true)
  const location = useLocation()
  const user = role === 'admin' ? CURRENT_USER_ADMIN : CURRENT_USER_COLABORADOR

  const isSpendHub = location.pathname.startsWith('/admin') || location.pathname.startsWith('/colaborador')

  return (
    <aside className="w-60 min-h-screen bg-white border-r border-hn-200 flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="px-5 py-4 border-b border-hn-100 flex items-center gap-2.5">
        <div
          className="w-8 h-8 rounded-m flex items-center justify-center text-white text-base font-bold"
          style={{ background: 'linear-gradient(135deg, #2c35a1 0%, #496be3 100%)' }}
        >
          H
        </div>
        <span className="text-ds-s font-semibold text-hn-950">Humand</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        <SideItem to="#" icon={<Clock size={16} />} label="Horarios laborales" disabled />
        <SideItem to="#" icon={<Users size={16} />} label="Control de asistencia" hasArrow disabled />
        <SideItem to="#" icon={<Newspaper size={16} />} label="Noticias" disabled />
        <SideItem to="#" icon={<LayoutGrid size={16} />} label="Mi Portal" disabled />
        <SideItem to="#" icon={<FileText size={16} />} label="Formularios y Trámites" disabled />
        <SideItem to="#" icon={<ClipboardList size={16} />} label="Encuestas" disabled />
        <SideItem to="#" icon={<Heart size={16} />} label="People Experience" hasArrow disabled />
        <SideItem to="#" icon={<GraduationCap size={16} />} label="Aprendizaje" hasArrow disabled />
        <SideItem to="#" icon={<Settings size={16} />} label="Gestión de servicios" hasArrow disabled />

        {/* SpendHub section */}
        <div>
          <button
            onClick={() => setSpendHubOpen((p) => !p)}
            className={`sidebar-item w-full justify-between ${isSpendHub ? 'sidebar-item-active' : ''}`}
          >
            <span className="flex items-center gap-3">
              <Wallet size={16} className={isSpendHub ? 'text-humand-500' : 'text-hn-600'} />
              <span className="text-ds-xs">SpendHub</span>
            </span>
            {spendHubOpen
              ? <ChevronDown size={14} className="text-hn-400" />
              : <ChevronRight size={14} className="text-hn-400" />
            }
          </button>

          {spendHubOpen && (
            <div className="ml-7 mt-0.5 space-y-0.5">
              {role === 'admin' ? (
                <>
                  <SubItem to="/admin/gastos"  label="Gestión de Gastos" />
                  <SubItem to="/admin/config"  label="Configuración" />
                  <SubItem to="/admin/metrics" label="Métricas" disabled />
                </>
              ) : (
                <>
                  <SubItem to="/colaborador/gastos" label="Mis Gastos" />
                </>
              )}
            </div>
          )}
        </div>

        <SideItem to="#" icon={<UserCheck size={16} />} label="Onboarding" disabled />
      </nav>

      {/* User */}
      <div className="px-3 py-3 border-t border-hn-100">
        <div className="flex items-center gap-3 px-3 py-2 rounded-m hover:bg-hn-50 cursor-pointer transition-colors">
          <Avatar initials={user.initials} name={user.name} size="sm" />
          <div className="flex-1 min-w-0">
            <p className="text-ds-xxs font-semibold text-hn-950 truncate">{user.name}</p>
            <p className="text-ds-xxxs text-hn-600 capitalize">{role}</p>
          </div>
          <BarChart2 size={14} className="text-hn-400 flex-shrink-0" />
        </div>
      </div>
    </aside>
  )
}

// ── Sub components ────────────────────────────────────────────────────────────

interface SideItemProps {
  to: string
  icon: React.ReactNode
  label: string
  hasArrow?: boolean
  disabled?: boolean
}

function SideItem({ to, icon, label, hasArrow, disabled }: SideItemProps) {
  if (disabled) {
    return (
      <div className="sidebar-item opacity-50 cursor-default select-none">
        <span className="text-hn-600">{icon}</span>
        <span className="flex-1">{label}</span>
        {hasArrow && <ChevronRight size={14} className="text-hn-400 ml-auto" />}
      </div>
    )
  }
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `sidebar-item ${isActive ? 'sidebar-item-active' : ''}`
      }
    >
      <span>{icon}</span>
      <span className="flex-1">{label}</span>
      {hasArrow && <ChevronRight size={14} className="text-hn-400 ml-auto" />}
    </NavLink>
  )
}

interface SubItemProps {
  to: string
  label: string
  disabled?: boolean
}

function SubItem({ to, label, disabled }: SubItemProps) {
  if (disabled) {
    return (
      <div className="px-3 py-2 text-ds-xs text-hn-400 cursor-default select-none rounded-s">
        {label}
      </div>
    )
  }
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `block px-3 py-2 text-ds-xs rounded-s transition-colors ${
          isActive
            ? 'text-humand-600 font-semibold bg-humand-50'
            : 'text-hn-800 hover:bg-hn-50 hover:text-hn-950'
        }`
      }
    >
      {label}
    </NavLink>
  )
}
