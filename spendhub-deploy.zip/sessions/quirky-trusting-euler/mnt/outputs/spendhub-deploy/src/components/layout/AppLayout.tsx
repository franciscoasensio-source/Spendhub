import type { ReactNode } from 'react'
import { Sidebar } from './Sidebar'
import type { Role } from '../../data/types'

interface AppLayoutProps {
  role: Role
  children: ReactNode
}

export function AppLayout({ role, children }: AppLayoutProps) {
  return (
    <div className="flex min-h-screen bg-hn-50">
      <Sidebar role={role} />
      <main className="flex-1 min-w-0 flex flex-col">
        {children}
      </main>
    </div>
  )
}

interface PageHeaderProps {
  title: string
  subtitle?: string
  actions?: ReactNode
}

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  return (
    <div className="bg-white border-b border-hn-200 px-8 py-5 flex items-center justify-between flex-shrink-0">
      <div>
        <h1 className="text-ds-l font-semibold text-hn-950">{title}</h1>
        {subtitle && <p className="text-ds-xs text-hn-600 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-3">{actions}</div>}
    </div>
  )
}
