// ── Shared ────────────────────────────────────────────────────────────────────

export type Role = 'admin' | 'colaborador'

export type Currency = 'ARS' | 'USD' | 'EUR' | 'BRL'

export type RequestStatus =
  | 'pendiente'
  | 'aprobado'
  | 'rechazado'
  | 'en_pago'
  | 'pagado'
  | 'rendicion_pendiente'

export interface StatusConfig {
  label: string
  bg: string
  color: string
  dotColor: string
}

// ── Users / People ────────────────────────────────────────────────────────────

export interface User {
  id: string
  name: string
  initials: string
  role: Role
  policyId: string
}

// ── Requests ──────────────────────────────────────────────────────────────────

export interface SpendRequest {
  id: string
  userId: string
  colaborador: string
  initials: string
  categoria: string
  monto: number
  moneda: Currency
  descripcion: string
  estado: RequestStatus
  fechaCreacion: string
  fechaDesde?: string
  fechaHasta?: string
  politica: string
  comentarioAprobador?: string
  aprobadoPor?: string
}

// ── Admin Config ──────────────────────────────────────────────────────────────

export type ApproverType =
  | 'specific_user'
  | 'direct_manager'
  | 'second_manager'
  | 'designated'
  | 'segmentation'
  | 'dynamic_field'

export type ApprovalRule = 'all_must_approve' | 'at_least_one'
export type ConditionOperator = 'AND' | 'OR'
export type ConditionField = 'custom_profile_field' | 'segmentation' | 'profile' | 'department' | 'position' | 'amount'
export type ConditionComparator = '=' | '>' | '<' | '>=' | '<='

export interface Condition {
  id: string
  field: ConditionField
  operator: ConditionComparator
  value: string | number
}

export interface Approver {
  id: string
  type: ApproverType
  value: string
  label: string
}

export interface PaymentResponsible {
  type: 'user' | 'role'
  value: string
  label: string
}

export interface CategoryRule {
  id: string
  name: string
  conditions: Condition[]
  conditionOperator: ConditionOperator
  approvers: Approver[]
  approvalRule: ApprovalRule
  paymentResponsible: PaymentResponsible
}

export interface Category {
  id: string
  name: string
  description: string
  rules: CategoryRule[]
  createdAt: string
}

export interface PolicyCategory {
  categoryId: string
  categoryName: string
}

export interface PolicyMember {
  userId: string
  name: string
  initials: string
}

export interface Policy {
  id: string
  name: string
  categories: PolicyCategory[]
  members: PolicyMember[]
  visibility: PolicyMember[]
  createdAt: string
}
