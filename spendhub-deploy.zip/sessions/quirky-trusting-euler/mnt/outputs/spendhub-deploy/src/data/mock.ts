import type { SpendRequest, Category, Policy, User, StatusConfig } from './types'

// ── Status config ─────────────────────────────────────────────────────────────

export const STATUS_CONFIG: Record<string, StatusConfig> = {
  pendiente:            { label: 'Pendiente',           bg: '#fcf7ce', color: '#b1690e', dotColor: '#f0b623' },
  aprobado:             { label: 'Aprobado',            bg: '#e6fbe9', color: '#249637', dotColor: '#4ed364' },
  rechazado:            { label: 'Rechazado',           bg: '#fde3e3', color: '#b22323', dotColor: '#e74444' },
  en_pago:              { label: 'En pago',             bg: '#ecfafc', color: '#30a2c7', dotColor: '#6fd1e7' },
  pagado:               { label: 'Pagado',              bg: '#e6fbe9', color: '#1f622c', dotColor: '#249637' },
  rendicion_pendiente:  { label: 'Rendición pendiente', bg: '#fef4ee', color: '#b52c19', dotColor: '#e9582b' },
}

// ── Users ─────────────────────────────────────────────────────────────────────

export const MOCK_USERS: User[] = [
  { id: 'usr-001', name: 'Lucas Fernández',   initials: 'LF', role: 'colaborador', policyId: 'pol-001' },
  { id: 'usr-002', name: 'Sofía Herrera',     initials: 'SH', role: 'colaborador', policyId: 'pol-001' },
  { id: 'usr-003', name: 'Tomás Aguirre',     initials: 'TA', role: 'colaborador', policyId: 'pol-002' },
  { id: 'usr-004', name: 'Valentina Cruz',    initials: 'VC', role: 'colaborador', policyId: 'pol-001' },
  { id: 'usr-005', name: 'Mateo Ríos',        initials: 'MR', role: 'colaborador', policyId: 'pol-001' },
  { id: 'usr-cfo', name: 'Marcela Ríos',      initials: 'MR', role: 'admin',       policyId: 'pol-002' },
  { id: 'usr-fin', name: 'Roberto Sánchez',   initials: 'RS', role: 'admin',       policyId: 'pol-002' },
]

export const CURRENT_USER_COLABORADOR = MOCK_USERS[0]  // Lucas Fernández
export const CURRENT_USER_ADMIN        = MOCK_USERS[5]  // Marcela Ríos

// ── Spend requests ────────────────────────────────────────────────────────────

export const MOCK_REQUESTS: SpendRequest[] = [
  {
    id: 'req-001', userId: 'usr-001',
    colaborador: 'Lucas Fernández', initials: 'LF',
    categoria: 'Viajes', monto: 850, moneda: 'ARS',
    descripcion: 'Vuelo Buenos Aires – Córdoba (ida y vuelta)',
    estado: 'pendiente', fechaCreacion: '2026-03-17',
    fechaDesde: '2026-03-20', fechaHasta: '2026-03-22',
    politica: 'Política Comercial',
  },
  {
    id: 'req-002', userId: 'usr-002',
    colaborador: 'Sofía Herrera', initials: 'SH',
    categoria: 'Alimentación', monto: 1200, moneda: 'ARS',
    descripcion: 'Almuerzo de trabajo con equipo comercial',
    estado: 'aprobado', fechaCreacion: '2026-03-14',
    fechaDesde: '2026-03-14', fechaHasta: '2026-03-14',
    politica: 'Política Comercial',
    aprobadoPor: 'Marcela Ríos',
  },
  {
    id: 'req-003', userId: 'usr-003',
    colaborador: 'Tomás Aguirre', initials: 'TA',
    categoria: 'Tecnología', monto: 299, moneda: 'USD',
    descripcion: 'Licencia anual Figma – equipo diseño',
    estado: 'en_pago', fechaCreacion: '2026-03-12',
    fechaDesde: '2026-03-12', fechaHasta: '2026-03-12',
    politica: 'Política Tech',
    aprobadoPor: 'Marcela Ríos',
  },
  {
    id: 'req-004', userId: 'usr-001',
    colaborador: 'Lucas Fernández', initials: 'LF',
    categoria: 'Tecnología', monto: 49, moneda: 'USD',
    descripcion: 'Suscripción Notion Pro (mensual)',
    estado: 'pagado', fechaCreacion: '2026-03-10',
    fechaDesde: '2026-03-10', fechaHasta: '2026-03-10',
    politica: 'Política Tech',
    aprobadoPor: 'Marcela Ríos',
  },
  {
    id: 'req-005', userId: 'usr-004',
    colaborador: 'Valentina Cruz', initials: 'VC',
    categoria: 'Viajes', monto: 3500, moneda: 'ARS',
    descripcion: 'Hotel 3 noches – Mendoza (reunión regional)',
    estado: 'rechazado', fechaCreacion: '2026-03-08',
    fechaDesde: '2026-03-18', fechaHasta: '2026-03-21',
    politica: 'Política Comercial',
    comentarioAprobador: 'Supera el límite aprobado para la categoría. Reenviar con monto ajustado.',
    aprobadoPor: 'Marcela Ríos',
  },
  {
    id: 'req-006', userId: 'usr-005',
    colaborador: 'Mateo Ríos', initials: 'MR',
    categoria: 'Alimentación', monto: 450, moneda: 'ARS',
    descripcion: 'Desayuno de trabajo con cliente',
    estado: 'pendiente', fechaCreacion: '2026-03-18',
    fechaDesde: '2026-03-18', fechaHasta: '2026-03-18',
    politica: 'Política Comercial',
  },
  {
    id: 'req-007', userId: 'usr-002',
    colaborador: 'Sofía Herrera', initials: 'SH',
    categoria: 'Viajes', monto: 620, moneda: 'ARS',
    descripcion: 'Taxi al aeropuerto internacional',
    estado: 'aprobado', fechaCreacion: '2026-03-16',
    fechaDesde: '2026-03-16', fechaHasta: '2026-03-16',
    politica: 'Política Comercial',
    aprobadoPor: 'Marcela Ríos',
  },
  {
    id: 'req-008', userId: 'usr-003',
    colaborador: 'Tomás Aguirre', initials: 'TA',
    categoria: 'Tecnología', monto: 89, moneda: 'USD',
    descripcion: 'Plugin UI Kit Figma – licencia empresa',
    estado: 'rendicion_pendiente', fechaCreacion: '2026-03-05',
    fechaDesde: '2026-03-05', fechaHasta: '2026-03-05',
    politica: 'Política Tech',
    aprobadoPor: 'Marcela Ríos',
  },
]

// ── Categories ────────────────────────────────────────────────────────────────

export const MOCK_CATEGORIES: Category[] = [
  {
    id: 'cat-001', name: 'Viajes',
    description: 'Transporte y alojamiento en viajes de trabajo',
    createdAt: '2025-01-10',
    rules: [
      {
        id: 'rule-001', name: 'Viajes – Argentina',
        conditions: [
          { id: 'c1', field: 'department', operator: '=', value: 'Ventas' },
          { id: 'c2', field: 'amount', operator: '<=', value: 1000 },
        ],
        conditionOperator: 'AND',
        approvers: [{ id: 'a1', type: 'direct_manager', value: '', label: 'Jefe directo' }],
        approvalRule: 'at_least_one',
        paymentResponsible: { type: 'role', value: 'finanzas', label: 'Equipo Finanzas' },
      },
      {
        id: 'rule-002', name: 'Viajes – Internacional',
        conditions: [{ id: 'c3', field: 'amount', operator: '>', value: 1000 }],
        conditionOperator: 'AND',
        approvers: [
          { id: 'a2', type: 'direct_manager', value: '', label: 'Jefe directo' },
          { id: 'a3', type: 'specific_user', value: 'usr-cfo', label: 'Marcela Ríos (CFO)' },
        ],
        approvalRule: 'all_must_approve',
        paymentResponsible: { type: 'user', value: 'usr-fin', label: 'Roberto Sánchez' },
      },
    ],
  },
  {
    id: 'cat-002', name: 'Alimentación',
    description: 'Comidas y bebidas en contexto laboral',
    createdAt: '2025-01-12',
    rules: [
      {
        id: 'rule-003', name: 'Alimentación general',
        conditions: [],
        conditionOperator: 'AND',
        approvers: [{ id: 'a4', type: 'direct_manager', value: '', label: 'Jefe directo' }],
        approvalRule: 'at_least_one',
        paymentResponsible: { type: 'role', value: 'finanzas', label: 'Equipo Finanzas' },
      },
    ],
  },
  {
    id: 'cat-003', name: 'Tecnología',
    description: 'Software, hardware y suscripciones tecnológicas',
    createdAt: '2025-02-01',
    rules: [],
  },
]

// ── Policies ──────────────────────────────────────────────────────────────────

export const MOCK_POLICIES: Policy[] = [
  {
    id: 'pol-001', name: 'Política Comercial',
    categories: [
      { categoryId: 'cat-001', categoryName: 'Viajes' },
      { categoryId: 'cat-002', categoryName: 'Alimentación' },
    ],
    members: [
      { userId: 'usr-001', name: 'Lucas Fernández',  initials: 'LF' },
      { userId: 'usr-002', name: 'Sofía Herrera',    initials: 'SH' },
      { userId: 'usr-004', name: 'Valentina Cruz',   initials: 'VC' },
      { userId: 'usr-005', name: 'Mateo Ríos',       initials: 'MR' },
    ],
    visibility: [{ userId: 'usr-fin', name: 'Roberto Sánchez', initials: 'RS' }],
    createdAt: '2025-01-15',
  },
  {
    id: 'pol-002', name: 'Política Tech',
    categories: [
      { categoryId: 'cat-003', categoryName: 'Tecnología' },
      { categoryId: 'cat-001', categoryName: 'Viajes' },
    ],
    members: [
      { userId: 'usr-003', name: 'Tomás Aguirre', initials: 'TA' },
    ],
    visibility: [{ userId: 'usr-cfo', name: 'Marcela Ríos', initials: 'MR' }],
    createdAt: '2025-02-10',
  },
]

// ── Segments ──────────────────────────────────────────────────────────────────

export const MOCK_SEGMENTS = [
  { id: 'seg-001', name: 'Comercial Argentina' },
  { id: 'seg-002', name: 'Comercial México' },
  { id: 'seg-003', name: 'Tech' },
  { id: 'seg-004', name: 'Operaciones' },
]
